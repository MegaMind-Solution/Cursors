I'm M.Ramzan Ch a Beginner Grphice Designer, Web Developer and Software Modifier.

I create some cursor packs with my Workgroup for windows PCs.

Credit goes to

MindRise Designs
MicroResearch Corpration®
Ideas & Management

MegaMind-Solution find idea to create Cursors

Designing partner

MindRise Deigns create amazing Designs.

Financial partner and Owner

MicroResearch Corpration®