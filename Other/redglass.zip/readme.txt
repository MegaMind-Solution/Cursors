﻿=== Red Glass Amaranth Cursor Set ===

By: Fythring (http://www.rw-designer.com/user/1751)

Download: http://www.rw-designer.com/cursor-set/redglass

Author's decription:

A shiny cursor set I made, called Red Glass Amaranth (has nothing to do with the flower). Sure to please a connoisseur of shiny things ;=).

==========

License: Creative Commons - Attribution

You are free:

* To Share - To copy, distribute and transmit the work.
* To Remix - To adapt the work.

Under the following conditions:

* Attribution - You must attribute the work in the manner specified
  by the author or licensor (but not in any way that suggests that
  they endorse you or your use of the work). For example, if you are
  making the work available on the Internet, you must link to the
  original source.