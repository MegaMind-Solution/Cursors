// Function to inject the cursor CSS into the active tab
function injectStyles(tabId) {
chrome.scripting.insertCSS({
target: { tabId: tabId },
files: ["styles.css"]
});
}

// Automatically inject CSS when a new tab is loaded or updated
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
if (changeInfo.status === "complete" && /^https?:/.test(tab.url)) {
injectStyles(tabId);
}
});