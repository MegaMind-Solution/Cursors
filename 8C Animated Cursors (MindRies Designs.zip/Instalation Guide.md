Instalation Guide

Right click on the .inf file
Then you see third option in context menu install click on it
After these steps go to settings>Personalization>themes
There you see a option cursors click on it
In popup window you select the cursor pack
Click on Apply button to apply cursors on Pc